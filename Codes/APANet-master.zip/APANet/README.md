## Introduction
This repository is a official PyTorch implementation of [APANet: Adaptive Prototypes Alignment Network for Few-Shot Semantic Segmentation](https://ieeexplore.ieee.org/document/9773019) (IEEE TMM 2022). This repo is created by Jiacheng Chen and Bin-Bin Gao.

<img src="figure/overview.png" width="800"/>


## Environment
+ mirrors: mirrors.tencent.com/jachymchen/pfenet:matting

## Datasets and Data Preparation
Please download the following datasets:

+ PASCAL-5i is based on the [**PASCAL VOC 2012**](http://host.robots.ox.ac.uk/pascal/VOC/voc2012/) and [**SBD**](http://home.bharathh.info/pubs/codes/SBD/download.html) where the val images should be excluded from the list of training samples.

+ [**COCO 2014**](https://cocodataset.org/#download).

This code reads data from .txt files where each line contains the paths for image and the correcponding label respectively. Image and label paths are seperated by a space. Example is as follows:

    image_path_1 label_path_1
    image_path_2 label_path_2
    image_path_3 label_path_3
    ...
    image_path_n label_path_n

Then update the train/val/test list paths in the config files.

We have uploaded the lists we use in our paper.
+ The train/val lists for COCO contain 82081 and 40137 images respectively. They are the default train/val splits of COCO. 
+ The train/val lists for PASCAL5i contain 5953 and 1449 images respectively. The train list should be **voc_sbd_merge_noduplicate.txt** and the val list is the original val list of pascal voc (**val.txt**).
+ We put the list of filtered images in **lists/pascal_list.txt** and **lists/coco_list.txt**

## Testing and Traning
**Testing**
+ Please download the ImageNet pretrained [**backbones**](https://mycuhk-my.sharepoint.com/:u:/g/personal/1155122171_link_cuhk_edu_hk/EQEY0JxITwVHisdVzusEqNUBNsf1CT8MsALdahUhaHrhlw?e=4%3a2o3XTL&at=9)
+ We directly provide the full [**pre-trained models**](https://drive.google.com/drive/folders/1nSOpJHk0CzPmbw32WPRZpc3xA58tdgOJ?usp=sharing). You can download them and directly extract them at the root of this repo. This includes VGG16, Resnet50 and Resnet101 backbones on Pascal-5i, and Resnet50, Resnet101 on Coco-20i.
+ Then execute the command: 

`python3 test.py {*split*} {*save_path*} {*k_num*} {*data_set*} {*train_gpu*}`

**Training**

Execute this command at the root directory: 

`sh start.sh`   

## Results on PASCAL-5i and COCO-20i 
**PASCAL-5i**

|1/5 shot|   Arch     | Fold-0 	   | Fold-1 	 | Fold-2 	   | Fold-3      | Mean 		|
| 	   ---      |    ---     |      ---    |	   ---   |	   ---     |    ---      |  ---  		|
| APANet       	| VGG-16     | 58.0 / 59.8 | 68.9 / 70.0 | 57.0 / 62.7 | 52.2 / 57.7 | 59.0 / 62.6	|
| APANet       	| Resnet-50  | 62.2 / 63.3 | 70.5 / 72.0 | 61.1 / 68.4 | 58.1 / 60.2 | 63.0 / 66.0	|
| APANet     	| Resnet-101 | 63.1 / 67.5 | 71.1 / 73.3 | 63.8 / 67.9 | 57.9 / 63.1 | 64.0 / 68.0  |

**COCO-20i**

|(1/5 shot)|   Arch     | Fold-0 	   | Fold-1 	 | Fold-2 	   | Fold-3      | Mean 		|
| 	   ---      |    ---     |      ---    |	   ---   |	   ---     |    ---      |  ---  		|
| APANet       	| Resnet-50  | 35.7 / 39.6 | 41.9 / 45.5 | 37.2 / 41.9 | 39.0 / 41.3 | 38.4 / 42.1	|
| APANet     	| Resnet-101 | 38.3 / 44.0 | 43.1 / 47.7 | 40.0 / 45.0 | 39.1 / 42.8 | 40.1 / 44.8  |

## Qualitative results
<img src="figure/visualization.png" width="800" />

## Citing

If you find this code useful in your research, please consider citing us:
```
@article{chen2022apanet,
  title={APANet: Adaptive Prototypes Alignment Network for Few-Shot Semantic Segmentation},
  author={Chen, Jiacheng and Gao, Bin-Bin and Lu, Zongqing and Xue, Jing-Hao and Wang, Chengjie and Liao, Qingmin},
  journal={IEEE Transactions on Multimedia},
  year={2022},
  publisher={IEEE}
}
```

## Acknowledgement
This repo is developed based on [PFENet](https://github.com/dvlab-research/PFENet)