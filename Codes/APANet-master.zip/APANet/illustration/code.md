## 运行步骤
#### Setp1. 
选择并按照想要的配置修改shell文件`SCNet/run_script/start_*.sh`
#### Setp2. 
修改shell文件`SCNet/start.sh` 
将其修改为：`sh ./run_script/start_*.sh`,  其中start_*.sh是setp1中选择的脚本
#### Setp3. 
在`run_script/`下，修改`config.json`，然后执行`sh jizhi.sh`

### 实验记录根路径：
/youtu/xlab-team2/persons/jachymchen/fs_seg/EXP_SCNet
#### 训练：
/youtu/xlab-team2/persons/jachymchen/fs_seg/EXP_SCNet/train
#### 推断：
/youtu/xlab-team2/persons/jachymchen/fs_seg/EXP_SCNet/inference
#### 批量分割可视化图路径：
/youtu/xlab-team2/persons/jachymchen/fs_seg/SCNet_visualization
## 配置shell文件`SCNet/run_script/start_*.sh`
Tips:<br>
1.训练和推断只需修改每个start_*.sh下的`stage`即可<br>
2.参数后的备注若有'only'字段表示该参数不需要更改<br>
3.baseline训练只需修改参数kmeans_flag=False
### Table1.Pascal-5i

|            |   **1-shot**     | **5-shot**	   |
| 	   :---:      |    :---     |      :---    |
|      **VGG-16**       	|**start_vgg.sh:**<br>data_set='pascal' <br>shot=1 |**start_vgg.sh:** <br>data_set='pascal'<br> shot=5 |
|      **ResNet-50**     	|**start_resnet.sh:**<br>data_set='pascal' <br>shot=1 <br>layers=50| **start_resnet.sh:**<br>data_set='pascal' <br>shot=5 <br>layers=50|
|      **ResNet-101**       |**start_resnet.sh:**<br>data_set='pascal' <br>shot=1 <br>layers=101  | **start_resnet.sh:**<br>data_set='pascal' <br>shot=5 <br>layers=101 | 
### Table2.COCO
|            |   **1-shot**     | **5-shot**	   |
| 	   :---:      |    :---     |      :---    |
|      **VGG-16**       	|**start_vgg.sh:**<br>data_set='coco' <br>shot=1 |**start_vgg.sh:** <br>data_set='coco'<br> shot=5 |
|      **ResNet-50**     	|**start_resnet.sh:**<br>data_set='coco' <br>shot=1 <br>layers=50| **start_resnet.sh:**<br>data_set='coco' <br>shot=5 <br>layers=50|
|      **ResNet-101**       |**start_resnet.sh:**<br>data_set='coco' <br>shot=1 <br>layers=101  | **start_resnet.sh:**<br>data_set='coco' <br>shot=5 <br>layers=101 | 

### Table3.聚类数量实验结果
**start_table3.sh:**<br> # 只需修改k_num<br>`k_num=5 # 1 2 3 4 5 `
### Table4.代理特征来源生成方法对性能的影响
**start_table4.sh**<br> # 无需任何修改
### Table5.损失函数超参的性能
**start_table5.sh:**<br> # 只需修改weight_kmeans<br>`weight_kmeans=0.1 # 0.1 0.3 0.5 0.7 0.9`

### Table6.使用网格划分对性能的评估
**start_table6.sh:**<br> # 只需修改bin_size <br> `bin_size=2 # 2 3 4 5`

### 可视化
在SCNet/demo_fig中上传好supp_img.jpg, supp_mask.png, qry_img.jpg<br>
在**start_demo.sh**下:<br>
`layers=50 # 50 or 101`<br>
`data_set='pascal' # 'pascal' or 'coco'`<br>
`split=0 # 0 1 2 3`<br>
`layers=50 # 50 101`
图片会保存为SCNet/demo_fig/demo_pred.png
### novel类计数
`cd /youtu/xlab-team2/persons/jachymchen/fs_seg/PFENet-novel_count`<br>
在**novel_count.sh**下:<br>
`data_set='pascal' # pascal or coco`<br>








