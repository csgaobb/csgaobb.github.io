# -*- coding: utf-8 -*-
Token = '8g7CVISzB32pjJTca3I2hQ'  # jachymchen
task_params = {
	'task_type': 'general_gpu_type',
	'common': {     
    	'business_flag': 'youtu_2020_budget',
    	'readable_name': 'PFENet', # task name
        'task_flag': 'pa_final_627', 
    	'dataset_id': '28A7DBF781F7446288FE747C16039581', 
    	'dataset_params': {                          
        'dataset_source': 'outer_ceph', 
          'dataset_name': 'youtu-ceph-xlab-team2-rw', 
      	     'path_info': {          
			'path': '/youtu/xlab-team2',
                        'addr': '9.23.1.81:6789,9.23.1.84:6789,9.23.1.85:6789',  
                        'name': 'youtu',
                      'secret': ''
		},
		          },
  
		'model_id': '', 
		'model_params': {
			'model_name': 'cifar10',  
			'model_path_info': {
				'model_source': 'local_upload',
				'path_info': {
					'file_path': '/youtu/xlab-team2/persons/jachymchen/fs_seg/PFENet-show'
				}
			}       
		},
    
  	},
	'task_config': {
		'designated_resource': {
			'host_num': 1,
			'host_gpu_num': 1,
			'is_resource_waiting': True,
			'image_full_name': 'mirrors.tencent.com/jachymchen/pfenet:matting'  
		},
		'hyper_parameters': {}
	}
}
