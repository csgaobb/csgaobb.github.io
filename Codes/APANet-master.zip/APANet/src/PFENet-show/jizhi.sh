jizhi_client start -cfg config.py
