# 声明：本代码基于GLIP_V1(https://github.com/microsoft/GLIP)原文代码构建

## 准备工作
### 环境搭建
太极docker：mirrors.tencent.com/increglip/increglip_v3:v3;  
参见GLIP_V1(https://github.com/microsoft/GLIP)搭建方式;  
若服务器无法联网，须自行下载bert 预训练tokenizer相关权重和设置“bert-base-uncased”,并配置目录到以下文件：  
maskrcnn_benckmark/modeling/detector/generalized_vl_rcnn.py --->line93  
maskrcnn_benckmark/modeling/language_backbone/bert_model.py --->line18  
maskrcnn_benckmark/modeling/rpn/vldyhead.py --->line567  
maskrcnn_benckmark/modeling/rpn/loss.py --->line548  
maskrcnn_benckmark/data/build.py --->line413  
maskrcnn_benckmark/engine/trainer.py --->line348 to line353  
maskrcnn_benchmark/tools/train_net.py --->line133  
maskrcnn_benchmark/engine/inference.py --->line265

配置swin-transformer 和bert 的预训练权重位置，在主目录下创建MODEL文件夹，MODEL目录下软连接到权重存储目录  
ln -s /path/to/target/swin_tiny_patch4_window7_224.pth /path/to/source/  
ln -s /path/to/target/pytorch_model.bin /path/to/source/  

### 数据集准备
使用VOC 2007和COCO 2017两个数据集，VOC 2007须转化为COCO格式，脚本见data_split/voc_coco.py;  
每个增量任务使用的标注文件划分见data_split/select_categories.py  

### 配置文件
训练测试配置文件见configs;  
#### 训练
在DATASETS.REGISTER中配置训练数据和标注路径，训练阶段默认不测试；  
修改DATASETS处BASE_CLASSE、INCRE_CLASS 和 TOTAL_CLASS  
#### 测试
在DATASETS.REGISTER中配置测试数据和标注路径  


## 训练
基类任务  
`python -m torch.distributed.launch --nnodes 1 --nproc_per_node=8 --master_port 8848 GLIP-main/tools/train_net.py \ `  
`--config-file ${配置文件路径}$.yaml \`  
`--skip-test --use-tensorboard --override_output_dir ${输出路径}$`  
增量任务   
`python -m torch.distributed.launch --nnodes 1 --nproc_per_node=8 --master_port 8848 GLIP-main/tools/train_net.py \`
`--config-file ${配置文件路径}$.yaml \`  
`--skip-test \`  
`MODEL.WEIGHT ${上一任务的训练权重}$.pth \`  
`OUTPUT_DIR ${输出路径}$`  
## 测试
`python -m torch.distributed.launch --nproc_per_node=7 --master_port 8991 tools/test_grounding_net.py \`  
`--config-file ${配置文件路径，例如coco.yaml}$.yaml \ `  
`--config-file-base ${配置文件路径，例如coco_base.yaml}$.yaml \ `  
`--weight_base ${训练权重}$.pth \`  
`--weight ${训练权重}$.pth \`  
`DATASETS.BASE_CLASSE ${基类数量}$ DATASETS.INCRE_CLASSE ${增量类数量}$ DATASETS.TOTAL_CLASSE ${总类数量}$ \`  
`OUTPUT_DIR ${输出目录}$ `  
特别注意！！！此处weight_base和weight应当是同一个权重，通过config-file和config-file-base来控制激活哪些channel；  
如果需要测试不同任务模型ensemble的结果，则weight_base和weight处放置相应任务的权重，同时注释掉maskrcnn_benckmark/modeling/detector/generalized_vl_rcnn.py --->line265-289    


# 致谢 GLIP_V1(https://github.com/microsoft/GLIP)











