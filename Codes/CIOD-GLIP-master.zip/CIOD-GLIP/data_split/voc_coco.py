# coding=utf-8
"""
@Purpose: 用于将voc 2007 格式数据集转化为coco格式
"""

import shutil
import os

def copy_images():
    # train_txt = "/home/ubuntu/hdd2/zhq/VOC2007/ImageSets/Main/trainval.txt"
    train_txt = "/youtu-public/VOCdevkit/VOC2007/ImageSets/Main/trainval.txt"
    # val_txt = "/home/ubuntu/hdd2/zhq/VOC2007/ImageSets/Main/test.txt"
    val_txt = "/youtu-public/VOCdevkit/VOC2007/ImageSets/Main/test.txt"
    train_img_id = open(train_txt,'r').readlines()
    val_img_id = open(val_txt,'r').readlines()

    train_img_id = [line.strip("\n") for line in train_img_id] # 5011
    val_img_id = [line.strip("\n") for line in val_img_id] # 4592

    # source_img_root_path = "/home/ubuntu/hdd2/zhq/VOC2007/JPEGImages/"
    # target_train_img_root_path = "/home/ubuntu/hdd2/zhq/voc_coco/train2007/"
    # target_val_img_root_path = "/home/ubuntu/hdd2/zhq/voc_coco/val2007/"

    source_img_root_path = "/youtu-public/VOCdevkit/VOC2007/JPEGImages/"
    target_train_img_root_path = "/apdcephfs/private_hqzzzhang/dataset/voc07/trainimages"
    target_val_img_root_path = "/apdcephfs/private_hqzzzhang/dataset/voc07/testimages"

    for img_id in train_img_id:
        source_img_path = os.path.join(source_img_root_path,img_id+'.jpg')
        target_img_path = os.path.join(target_train_img_root_path,img_id+'.jpg')
        shutil.copy(source_img_path, target_img_path)

    for img_id in val_img_id:
        source_img_path = os.path.join(source_img_root_path,img_id+'.jpg')
        target_img_path = os.path.join(target_val_img_root_path,img_id+'.jpg')
        shutil.copy(source_img_path, target_img_path)


import os
from tqdm import tqdm
import xml.etree.ElementTree as ET
import json

class_names = CLASS_NAMES = [
    "aeroplane", "bicycle", "bird", "boat", "bottle", "bus", "car", "cat",
    "chair", "cow", "diningtable", "dog", "horse", "motorbike", "person",
    "pottedplant", "sheep", "sofa", "train", "tvmonitor",
]
class_names_ids = {"aeroplane":1, "bicycle":2, "bird":3, "boat":4, "bottle":5, "bus":6, "car":7, "cat":8,
    "chair":9, "cow":10, "diningtable":11, "dog":12, "horse":13, "motorbike":14, "person":15,
    "pottedplant":16, "sheep":17, "sofa":18, "train":19, "tvmonitor":20,}

# def voc2coco(data_dir, train_file, val_file, test_file):
def voc2coco(data_dir, train_file, test_file):
    xml_dir = os.path.join(data_dir, 'xml_ann')
    img_dir = os.path.join(data_dir, 'JPEGImages')

    with open(train_file, 'r') as f:
        train_fs = f.readlines()
    train_xmls = [os.path.join(xml_dir, n.strip() + '.xml') for n in train_fs]
    # with open(val_file, 'r') as f:
        # val_fs = f.readlines()
    # val_xmls = [os.path.join(xml_dir, n.strip() + '.xml') for n in val_fs]
    with open(test_file, 'r') as f:
        test_fs = f.readlines()
    test_xmls = [os.path.join(xml_dir, n.strip() + '.xml') for n in test_fs]
    print('got xmls')
    train_coco = xml2coco(train_xmls)
    # val_coco = xml2coco(val_xmls)
    test_coco = xml2coco(test_xmls)
    # with open(os.path.join(data_dir, 'coco_train.json'), 'w') as f:
    with open(os.path.join(data_dir, 'annotations/voc_train.json'), 'w') as f:
        json.dump(train_coco, f, ensure_ascii=False, indent=2)
    # with open(os.path.join(data_dir, 'coco_val.json'), 'w') as f:
    # with open(os.path.join(data_dir, 'voc_val.json'), 'w') as f:
        # json.dump(val_coco, f, ensure_ascii=False, indent=2)
    # with open(os.path.join(data_dir, 'coco_test.json'), 'w') as f:
    with open(os.path.join(data_dir, 'annotations/voc_test.json'), 'w') as f:
        json.dump(test_coco, f, ensure_ascii=False, indent=2)
    print('done')

def xml2coco(xmls):
    coco_anno = {'info': {}, 'images': [], 'licenses': [], 'annotations': [], 'categories': []}
    coco_anno['categories'] = [{'supercategory': j, 'id': i + 1, 'name': j} for i, j in enumerate(class_names)]
    img_id = 0
    anno_id = 0
    for fxml in tqdm(xmls):
        try:
            tree = ET.parse(fxml)
            objects = tree.findall('object')
        except:
            print('err xml file: ', fxml)
            continue
        if len(objects) < 1:
            print('no object in ', fxml)
            continue
        img_id += 1
        size = tree.find('size')
        ih = float(size.find('height').text)
        iw = float(size.find('width').text)
        img_name = fxml.strip().split('/')[-1].replace('xml', 'jpg')
        img_name = img_name.split('\\')
        img_name = img_name[-1]
        img_info = {}
        img_info['id'] = img_id
        img_info['file_name'] = img_name
        img_info['height'] = ih
        img_info['width'] = iw
        coco_anno['images'].append(img_info)

        for obj in objects:
            cls_name = obj.find('name').text
            bbox = obj.find('bndbox')
            x1 = float(bbox.find('xmin').text)
            y1 = float(bbox.find('ymin').text)
            x2 = float(bbox.find('xmax').text)
            y2 = float(bbox.find('ymax').text)
            if x2 < x1 or y2 < y1:
                print('bbox not valid: ', fxml)
                continue
            anno_id += 1
            bb = [x1, y1, x2 - x1, y2 - y1]
            categery_id = class_names.index(cls_name) + 1
            area = (x2 - x1) * (y2 - y1)
            anno_info = {}
            anno_info['segmentation'] = []
            anno_info['area'] = area
            anno_info['image_id'] = img_id
            anno_info['bbox'] = bb
            anno_info['iscrowd'] = 0
            # anno_info['category_id'] = categery_id
            anno_info['category_id'] = class_names_ids[cls_name]
            anno_info['id'] = anno_id
            coco_anno['annotations'].append(anno_info)

    return coco_anno

if __name__ == '__main__':
    # step 1, copy voc image format (JPEGImages/) to coco format (train/, val/)
    # copy_images() # need change path in it

    # step 2, voc annotations .xml to coco .json
    # save_path = "/apdcephfs/private_hqzzzhang/dataset/voc07/"
    data_dir = "/apdcephfs/private_hqzzzhang/dataset/voc07/"
    train_file = "/youtu-public/VOCdevkit/VOC2007/ImageSets/Main/trainval.txt"
    # val_file = "/data2/zhq/dataset/voc_coco/annotations/val.txt"
    test_file = "/youtu-public/VOCdevkit/VOC2007/ImageSets/Main/test.txt"
    voc2coco(data_dir,train_file,test_file)
