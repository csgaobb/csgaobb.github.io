from .flickr_eval import FlickrEvaluator
