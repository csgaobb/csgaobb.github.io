## Introduction

This repository is a official PyTorch implementation of A Coarse-to-fine Instance Segmentation Network with Learning Boundary Representation (IJCNN 2021). This repo is created by Feng Luo.


<div align="center"><img src="imgs/architecture.png" width="600"></div>

## Installation
This repo is based on [mmdetection](https://github.com/open-mmlab/mmdetection)(1.0.rc0). Please check [INSTALL.md](INSTALL.md) for installation details.

## Training and Testing
**Train:**
- ``` sh ./tools/dist_train.sh configs/polarmask_refine/4gpu/polar_init_refine_r101_centerness_polar_heatmap_4_10.py  4 --launcher pytorch --work_dir ./work_dirs/cf_hbb_r101```

**Testing:**
- ```sh tools/dist_test.sh configs/polarmask_refine/4gpu/polar_init_refine_r101_centerness_polar_heatmap_4_10.py ./work_dirs/cf_hbb_r101/cf_hbb_r101.pth 4 --out work_dirs/cf_hbb_r101/res.pkl --eval segm```

**Visualization:**
- ```python3 demo/vis.py ----contour_line --color_mask```


## Performance
<div align="center"><img src="imgs/quality_results.png" width="800"></div>
<div align="center"><img src="imgs/quantitive_results.png" width="800"></div>

## Ablation Studies and Pre-trained Models
| Backbone  | Coarse-to-fine  | Holistic boundary-aware | Mask AP | config |        Model        |
|:---------:|:---------------:|:-----------------------:|:-------:|:------:|:-------------------:|
| R-101     |       No        |            No           |   30.4  |configs/polarmask_refine/4gpu/polar_init_centerness_polar_r101.py| [baseline_r101.pth](https://drive.google.com/file/d/1VWrHNlM2qtqRYSlhbRZARIqdqxjjGMXI/view?usp=sharing)|
| R-101     |       Yes       |            No           |   31.2  |configs/polarmask_refine/4gpu/polar_init_refine_r101_centerness_polar.py|   [cf_r101.pth](https://drive.google.com/file/d/1Irdivsavb1BsOUHeJWzrplfRHX0SWuQN/view?usp=sharing)    |
| R-101     |       Yes       |            Yes          |   31.7  |configs/polarmask_refine/4gpu/polar_init_refine_r101_centerness_polar_heatmap_4_10.py|  [cf_hbb_r101.pth](https://drive.google.com/file/d/1JEoEkvJRekLqVxSp7OtCaOCJ8Uj0WyNl/view?usp=sharing)|

Trained models can be download in [Google Drive](https://drive.google.com/drive/folders/1USjZB5N9BT-pKt_GwSnydCfIoXQesWgV?usp=sharing).

## Results on COCO test-dev
[Link](https://minioec-proxy.lri.fr/prod-private/submission_stdout/782522/1be25/stdout.txt?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Expires=86400&X-Amz-SignedHeaders=host&X-Amz-Signature=a4bb6f3de9ebb2c1cd7c086fcb30c278f587981fce27d97b6efa4e6b2d6d70f7&X-Amz-Date=20210413T080146Z&X-Amz-Credential=AZIAIOSAODNN7EX123LE%2F20210413%2Fminioec-proxy%2Fs3%2Faws4_request)


## Citing
If you find this code useful in your research, please consider citing us:
```
@inproceedings{luo2021coarse,
  title={A coarse-to-fine instance segmentation network with learning boundary representation},
  author={Luo, Feng and Gao, Bin-Bin and Yan, Jiangpeng and Li, Xiu},
  booktitle={2021 International Joint Conference on Neural Networks (IJCNN)},
  pages={1--8},
  year={2021},
  organization={IEEE}
}
```
