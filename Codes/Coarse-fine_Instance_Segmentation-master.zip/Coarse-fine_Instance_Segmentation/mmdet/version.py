# GENERATED VERSION FILE
# TIME: Sat Jan 23 20:33:36 2021

__version__ = '1.0.rc0+unknown'
short_version = '1.0.rc0'
