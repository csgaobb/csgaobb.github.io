cd /apdcephfs/private_amandaaluo/PolarMask

python3 setup.py develop

pip install future tensorboard

sh ./tools/dist_train.sh configs/polarmask_refine/4gpu/polar_init_refine_r101_centerness_polar_heatmap_4_10.py  4 --launcher pytorch --work_dir ./work_dirs/polar_init_refine_r101_centerness_polar_heatmap_4_10


