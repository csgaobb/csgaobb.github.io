from .resnet import resnet101
from .resnet import resnet50

