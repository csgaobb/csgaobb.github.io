git  clone git@github.com:zhzhanp/TCDCN-face-alignment.git TCDCN
git  clone git@github.com:pdollar/toolbox.git              Piotr-CV
wget http://www.cis.upenn.edu/~jshi/software/Ncut_9.zip 
unzip Ncut_9.zip
rm Ncut_9.zip

wget https://lvdmaaten.github.io/drtoolbox/code/drtoolbox.tar.gz
tar -zxvf drtoolbox.tar.gz
rm drtoolbox.tar.gz

git clone git@github.com:altmany/export_fig.git

wget https://github.com/vlfeat/matconvnet/archive/v1.0-beta18.tar.gz 
tar -zxvf v1.0-beta18.tar.gz  matconvnet-1.0-beta18
rm v1.0-beta18.tar.gz

git clone git@github.com:pdollar/edges.git