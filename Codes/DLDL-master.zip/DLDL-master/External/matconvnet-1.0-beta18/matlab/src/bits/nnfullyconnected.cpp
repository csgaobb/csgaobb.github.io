#ifdef ENABLE_GPU
#error "The file nnfullyconnected.cu should be compiled instead"
#endif
#include "nnfullyconnected.cu"
