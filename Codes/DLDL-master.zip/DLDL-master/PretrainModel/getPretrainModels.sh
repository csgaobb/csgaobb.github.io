# get vgg-16
wget http://www.vlfeat.org/matconvnet/models/imagenet-vgg-verydeep-16.mat
# get vgg-19
wget http://www.vlfeat.org/matconvnet/models/imagenet-vgg-verydeep-16.mat
# get vggface
wget http://www.vlfeat.org/matconvnet/models/vgg-face.mat
