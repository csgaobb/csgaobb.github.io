please download pre-trained face recongnition model from the following link.
