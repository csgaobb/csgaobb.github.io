# CSTrans for Counting Everything

This is the implementation of the CSTrans for few-shot counting, which follows the FamNet:

```
Learning To Count Everything
Viresh Ranjan, Udbhav Sharma, Thu Nguyen and Minh Hoai
Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR), 2021.
```

The code is modified from https://github.com/cvlab-stonybrook/LearningToCountEverything, the official implementation of the FamNet.

## Preparatory work

The dataset can be downloaded from here: https://drive.google.com/file/d/1ymDYrGs9DSRicfZbSCDiOu0ikGDh5k6S/view?usp=sharing.

The precomputed density maps can be found here: https://archive.org/details/FSC147-GT.

The whole project directory structure is:

```
PROJECT_DIR
  |--datasets
       |--FSC-147
            |--annotation_FSC-147.json
            |--gt_density_map_adaptive
            |--gt_density_map_adaptive_vis
            |--ImageClasses_FSC-147.txt
            |--img
            |--img_vis
            |--Train_Test_Val_FSC-147.json
  |--cst (the folder name of this source codes)
  |--outputs (auto-created when running this source codes)
  |--torchvision_pretrained_models
```

Before running the codes, please specify the ```PROJECT_DIR``` in ```tools/constants.py```.

## Training
The training commands are summarized in the ```run_train.sh```.

## Testing
For testing, please set the ```dir_list_list``` of ```run_test.py```, and run:

```
python3 run_test.py
```
